#ifndef KATANA_ENTERPRISE__AMP_MACROS_H_
#define KATANA_ENTERPRISE__AMP_MACROS_H_

#define _AMP_PROPAGATE_ARROW_ERROR(v) if (auto r = v; !r.ok()) { return katana::ErrorCode::ArrowError; }

#endif
