/*
 * This file belongs to the Galois project, a C++ library for exploiting
 * parallelism. The code is being released under the terms of the 3-Clause BSD
 * License (a copy is located in LICENSE.txt at the top-level directory).
 *
 * Copyright (C) 2018, The University of Texas at Austin. All rights reserved.
 * UNIVERSITY EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES CONCERNING THIS
 * SOFTWARE AND DOCUMENTATION, INCLUDING ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR ANY PARTICULAR PURPOSE, NON-INFRINGEMENT AND WARRANTIES OF
 * PERFORMANCE, AND ANY WARRANTY THAT MIGHT OTHERWISE ARISE FROM COURSE OF
 * DEALING OR USAGE OF TRADE.  NO WARRANTY IS EITHER EXPRESS OR IMPLIED WITH
 * RESPECT TO THE USE OF THE SOFTWARE OR DOCUMENTATION. Under no circumstances
 * shall University be liable for incidental, special, indirect, direct or
 * consequential damages or loss of profits, interruption of business, or
 * related expenses which may arise from use of Software or Documentation,
 * including but not limited to those resulting from defects in Software and/or
 * Documentation, or loss or inaccuracy of data of any kind.
 */

#ifndef KATANA_LIBGALOIS_KATANA_ENVCHECK_H_
#define KATANA_LIBGALOIS_KATANA_ENVCHECK_H_

#include <cassert>
#include <string>

#include "katana/config.h"

namespace katana {

namespace internal {

template <typename T>
struct ConvByType {};

template <>
struct ConvByType<int> {
  static void go(const char* varVal, int& ret) {
    KATANA_LOG_DEBUG_ASSERT(varVal);
    ret = std::atoi(varVal);
  }
};

template <>
struct ConvByType<double> {
  static void go(const char* varVal, double& ret) {
    KATANA_LOG_DEBUG_ASSERT(varVal);
    ret = std::atof(varVal);
  }
};

template <>
struct ConvByType<std::string> {
  static void go(const char* varVal, std::string& ret) {
    KATANA_LOG_DEBUG_ASSERT(varVal);
    ret = varVal;
  }
};

template <typename T>
bool
genericGetEnv(const char* varName, T& ret) {
  char* varVal = getenv(varName);
  if (varVal) {
    ConvByType<T>::go(varVal, ret);
    return true;
  } else {
    return false;
  }
}

}  // end namespace internal

//! Return true if the Enviroment variable is set
bool EnvCheck(const char* varName);
bool EnvCheck(const std::string& varName);

/**
 * Return true if Enviroment variable is set, and extract its value into
 * 'retVal' parameter
 * @param varName: name of the variable
 * @param retVal: lvalue to store the value of environment variable
 * @return true if environment variable set, false otherwise
 */
template <typename T>
bool
EnvCheck(const char* varName, T& retVal) {
  return internal::genericGetEnv(varName, retVal);
}

template <typename T>
bool
EnvCheck(const std::string& varName, T& retVal) {
  return EnvCheck(varName.c_str(), retVal);
}

}  // end namespace katana

#endif
